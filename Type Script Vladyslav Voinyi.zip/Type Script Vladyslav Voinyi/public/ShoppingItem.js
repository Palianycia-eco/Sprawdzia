export default class ShopingItem {
    id;
    name;
    quantity;
    isBought;
    constructor(id, name, quantity, isBought = false) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.isBought = isBought;
    }
    toogle() {
        this.isBought = !this.isBought;
    }
    render() {
        const div = document.createElement("div");
        div.classList.add("item");
        if (this.isBought) {
            div.classList.add("bought");
        }
        div.setAttribute("data-id", String(this.id));
        const nameSpan = document.createElement("span");
        nameSpan.classList.add("item-name");
        nameSpan.textContent = this.name;
        const quantitySpan = document.createElement("span");
        quantitySpan.classList.add("item-quantty");
        quantitySpan.textContent = String(this.quantity);
        const toggleBtn = document.createElement("button");
        toggleBtn.classList.add("toggle-btn");
        toggleBtn.textContent = this.isBought ?
            "CoFnij" : "Kupione";
        const deleteBtn = document.createElement("button");
        deleteBtn.classList.add("delete-btn");
        deleteBtn.textContent = "Usun";
        div.appendChild(nameSpan);
        div.appendChild(quantitySpan);
        div.appendChild(toggleBtn);
        div.appendChild(deleteBtn);
        return div;
    }
}
