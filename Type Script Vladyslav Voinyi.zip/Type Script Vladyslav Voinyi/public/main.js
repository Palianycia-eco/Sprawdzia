import ShopingList from "./ShoppingList.js";
import { validateItem } from "./validation.js";
const nameInput = document.getElementById("nameInput");
const quantityInput = document.getElementById("quantityInput");
const addButton = document.getElementById("addButton");
const errorMessge = document.getElementById("errorMessge");
const filterSelect = document.getElementById("filterSelect");
const counter = document.getElementById("counter");
const listContiner = document.getElementById("listContiner");
const clearBoughtButton = document.getElementById("clearBoughtButton");
const list = new ShopingList();
function render() {
    const items = list.getFiltered(filterSelect.value);
    listContiner.textContent = "";
    items.array.forEach((item => {
        listContiner.appendChild(items.render());
    }));
    counter.textContent = "Do kupienia: " + list.countRemaining();
}
addButton.addEventListener("click", () => {
    const error = validateItem(nameInput.value, quantityInput.value);
    if (error !== null) {
        errorMessge.textContent = error;
        return;
    }
    list.add(nameInput.value.trim(), Number(quantityInput.value));
    errorMessge.textContent = "";
    nameInput.value = "",
        quantityInput.value = "",
        render();
});
