export default class ShopingList {
    item = [];
    nextId;
    number = 1;
}
