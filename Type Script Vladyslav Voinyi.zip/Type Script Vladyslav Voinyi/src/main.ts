import ShopingList, { ItemFilter } from "./ShoppingList.js";

import { validateItem } from "./validation.js";

const nameInput = document.getElementById("nameInput") as HTMLInputElement;

const quantityInput = document.getElementById("quantityInput") as HTMLInputElement;

const addButton = document.getElementById("addButton") as HTMLInputElement;

const errorMessge = document.getElementById("errorMessge") as HTMLInputElement;

const filterSelect = document.getElementById("filterSelect") as HTMLInputElement;

const counter = document.getElementById("counter") as HTMLInputElement;

const listContiner = document.getElementById("listContiner") as HTMLInputElement;

const clearBoughtButton = document.getElementById("clearBoughtButton") as HTMLInputElement | null;

const list = new ShopingList();

function render(): void {
  const items = list.getFiltered(filterSelect.value as ItemFilter);

  listContiner.textContent = "";
  items.array.forEach((item => {
    listContiner.appendChild(items.render());
  });

  counter.textContent = "Do kupienia: " + list.countRemaining();
}


addButton.addEventListener("click", () => {
  const error = validateItem(nameInput.value, quantityInput.value);

  if (error !== null) {
    errorMessge.textContent = error;
    return;
  }

  list.add(nameInput.value.trim(),
  Number(quantityInput.value));

  errorMessge.textContent = "";
  nameInput.value = "",
  quantityInput.value = "",

  render();
});
