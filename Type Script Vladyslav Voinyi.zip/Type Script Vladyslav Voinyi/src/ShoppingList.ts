import ShopingItem from "./ShoppingItem.js";

export type ItemFilter = "all" | "toBuy" | "bought";

export default class ShopingList {
  item: ShopingItem[] = [];
  private nextId; number = 1;

  add(name)
}